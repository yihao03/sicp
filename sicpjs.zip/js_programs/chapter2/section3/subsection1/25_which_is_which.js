'"' === "";

// expected: false
