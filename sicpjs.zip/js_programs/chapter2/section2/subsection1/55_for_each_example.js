// for_each to be given by student
for_each(x => x, 
         list(57, 321, 88));
