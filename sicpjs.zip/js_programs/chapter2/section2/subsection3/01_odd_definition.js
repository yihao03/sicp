function is_odd(n) {
    return n % 2 === 1;
}
