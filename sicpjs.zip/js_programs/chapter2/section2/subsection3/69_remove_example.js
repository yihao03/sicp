length(remove(3, list(1, 2, 3, 4, 5)));
