function make_branch(length, structure) {
    return list(length, structure);
}
