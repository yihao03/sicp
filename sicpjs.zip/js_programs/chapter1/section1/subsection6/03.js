function abs(x) {
    return x > 0
           ? x
           : x === 0
           ? 0
           : - x;
}

abs(-5);
