const a = 3;
const b = a + 1;
2 + (b > a ? b : a);

// expected: 6
