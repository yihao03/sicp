function abs(x) {
    return x >= 0 ? x : - x;
}

abs(-5);
