function square(y) {
    return y * y;
}

square(14);
