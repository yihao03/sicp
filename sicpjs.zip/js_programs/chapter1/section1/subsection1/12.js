1 - 5 / 2 * 4 + 3;

// expected: -6
