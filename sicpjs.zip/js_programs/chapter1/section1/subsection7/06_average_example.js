average(3, 6);
