function random(n) {
    return math_floor(math_random() * n);
}
