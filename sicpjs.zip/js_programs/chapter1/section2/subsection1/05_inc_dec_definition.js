function inc(x) {
    return x + 1;
}
function dec(x) {
    return x - 1;
}
