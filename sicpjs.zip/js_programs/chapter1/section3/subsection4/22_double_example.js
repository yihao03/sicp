// double to be written by student; see EXERCISE 1.41
function inc(n) {
    return n + 1;
}
double(double(double))(inc)(5);
