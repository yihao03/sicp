// double to be written by student; see EXERCISE 1.41
