search(x => x * x - 1, 0, 2);
