function plus4(x) { 
    return x + 4; 
}

plus4(3);
